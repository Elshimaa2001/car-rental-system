<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Car Rental</title>
    <link rel="stylesheet" href="styles.css">

<style media="screen">
  body{
     background-color: white;
  }
</style>
    <!--fonts-->
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Lobster+Two:ital@1&family=Rubik:wght@600&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="index">
    <h1 style="text-shadow: 2px 2px white;">Car Rental</h1>
    <p class="indexp">rent your own now...</p>
    <button type="button" name="indexb"  style="background-color: white; border-color: #C84B31; border-style: solid;"><a style="color:#2D4263" class="indexa"href="./system.php">System User</a></button>
    <button type="button" name="indexb" style="background-color: white; border-color: #C84B31; border-style: solid;" ><a style="color:#2D4263" class="indexa"href="./customer.php">Customer</a></button>

  </div>
  </body>
</html>
